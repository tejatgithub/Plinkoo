# p5.play-boilerplate
Boiler plate for p5.play
